# For capturing the data of face
import cv2
import os

# Path to the directory containing the script
script_dir = os.path.dirname(os.path.abspath(__file__))
print("Script directory:", script_dir)

# Load the pre-trained cascade classifier for face detection
cascade_path = os.path.join(script_dir, 'haarcascade_frontalface_default.xml')
face_detector = cv2.CascadeClassifier(cascade_path)

# Check if the cascade classifier was successfully loaded
if face_detector.empty():
    print("Error: Could not load cascade classifier")
    exit()

# Open the webcam
cam = cv2.VideoCapture(0)
cam.set(3, 640) # set video width
cam.set(4, 480) # set video height

# List of names
list_names = ['Hittanshu', 'Vedant']

# Print names with numeric list like this 1. name 2. name 3. name
for i, name in enumerate(list_names, start=1):
    print(f"{i}. {name}")

# For each person, enter one numeric face id
face_id = input('\n Enter user id and press <return> ==>  ')

print("\n [INFO] Initializing face capture. Look at the camera and wait ...")
# Initialize individual sampling face count
count = 0

while(True):
    ret, img = cam.read()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)
        count += 1

        # Save the captured image into the datasets folder
        image_path = os.path.join(script_dir, "dataset", f"User.{face_id}.{count}.jpg")
        print("Saving image to:", image_path)
        cv2.imwrite(image_path, gray[y:y+h, x:x+w])
        cv2.imshow('image', img)

    k = cv2.waitKey(100) & 0xff # Press 'ESC' for exiting video
    if k == 27:
        break
    elif count >= 30: # Take 30 face samples and stop video
        break

# Clean up
print("\n [INFO] Exiting Program and cleaning up")
cam.release()
cv2.destroyAllWindows()
