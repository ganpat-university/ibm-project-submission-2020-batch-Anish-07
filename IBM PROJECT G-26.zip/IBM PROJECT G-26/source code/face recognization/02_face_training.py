import cv2
import numpy as np
import os

# Path for face image database
dataset_path = "/Users/hittanshubhanderi/Downloads/Face_Recognition /Facial-Recognition/dataset"
trainer_path = "/Users/hittanshubhanderi/Downloads/Face_Recognition /Facial-Recognition/trainer"

# Check if the XML file exists
xml_path = "/Users/hittanshubhanderi/Downloads/Face_Recognition /Facial-Recognition/haarcascade_frontalface_default.xml"
if not os.path.exists(xml_path):
    print("[ERROR] Haar cascade XML file not found. Please ensure it exists in the current directory.")
    exit()

# Check if the dataset directory exists
if not os.path.exists(dataset_path):
    print("[ERROR] Dataset directory not found. Please check the path:", dataset_path)
    exit()

# Create face recognizer and detector
recognizer = cv2.face.LBPHFaceRecognizer_create()
detector = cv2.CascadeClassifier(xml_path)

# Function to get the images and label data
def getImagesAndLabels(path):
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    faceSamples = []
    ids = []

    for imagePath in imagePaths:
        img = cv2.imread(imagePath)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Detect faces
        faces = detector.detectMultiScale(gray)

        for (x, y, w, h) in faces:
            faceSamples.append(gray[y:y+h, x:x+w])
            # Extract the user ID from the image file name
            id = int(os.path.split(imagePath)[-1].split(".")[1])
            ids.append(id)

    return faceSamples, ids

# Train the recognizer
def trainRecognizer(dataset_path, trainer_path):
    try:
        faces, ids = getImagesAndLabels(dataset_path)
        recognizer.train(faces, np.array(ids))

        # Save the trained model
        recognizer.save(os.path.join(trainer_path, "trainer.yml"))
        print("\n [INFO] {0} faces trained. Exiting Program".format(len(np.unique(ids))))
    except FileNotFoundError:
        print("\n [ERROR] Dataset directory not found. Please check the path:", dataset_path)
    except Exception as e:
        print("\n [ERROR] An error occurred during training:", str(e))

# Train the recognizer
print("\n [INFO] Training faces. It will take a few seconds. Please wait ...")
trainRecognizer(dataset_path, trainer_path)
