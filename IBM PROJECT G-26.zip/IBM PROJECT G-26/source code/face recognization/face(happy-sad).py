import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load the face detection cascade
face_cascade_path = cv2.data.haarcascades + '/haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(face_cascade_path)
if face_cascade.empty():
    print("Error: Unable to load face cascade.")
    exit()

# Load the pre-trained model for facial expression recognition
emotion_model = load_model("/Users/hittanshubhanderi/Downloads/Face_Recognition /Facial-Detection/emotion_model.hdf5")

# Define the labels for facial expressions
emotion_labels = {0: 'Angry', 1: 'Disgust', 2: 'Fear', 3: 'Happy', 4: 'Sad', 5: 'Surprise', 6: 'Neutral'}

# Initialize the video capture
video_capture = cv2.VideoCapture(0)

while True:
    # Read the frame from the video capture
    ret, frame = video_capture.read()
    if not ret:
        print("Error reading frame from camera")
        break

    # Convert frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        # Extract the face region
        face_roi = gray[y:y+h, x:x+w]

        # Resize the face region to match the input shape of the model
        face_roi_resized = cv2.resize(face_roi, (64, 64))

        # Preprocess the face region for emotion recognition
        face_roi_resized = np.expand_dims(face_roi_resized, axis=-1)
        face_roi_resized = np.expand_dims(face_roi_resized, axis=0)
        face_roi_resized = face_roi_resized / 255.0

        # Perform emotion prediction using the model
        emotion_prediction = emotion_model.predict(face_roi_resized)
        emotion_label_arg = np.argmax(emotion_prediction)
        emotion_label = emotion_labels[emotion_label_arg]

        # Draw the bounding box around the face
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

        # Draw the text indicating the detected facial expression
        cv2.putText(frame, "Emotion: {}".format(emotion_label), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

    # Display the resulting frame
    cv2.imshow('Facial Expression Detection', frame)

    # Break the loop on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture and close all windows
video_capture.release()
cv2.destroyAllWindows()
