import cv2
import os

# Load the LBPH face recognizer
recognizer = cv2.face.LBPHFaceRecognizer_create()

# Provide the correct path to the trained model
trainer_path = "/Users/hittanshubhanderi/Downloads/Face_Recognition /Facial-Recognition/trainer/trainer.yml"
if not os.path.exists(trainer_path):
    print("[ERROR] Trainer file not found. Please check the path:", trainer_path)
    exit()

recognizer.read(trainer_path)

# Provide the correct path to the cascade classifier XML file
cascadePath = "/Users/hittanshubhanderi/Downloads/Face_Recognition /Facial-Recognition/haarcascade_frontalface_default.xml"
if not os.path.exists(cascadePath):
    print("[ERROR] Cascade classifier XML file not found. Please ensure it exists in the current directory.")
    exit()

faceCascade = cv2.CascadeClassifier(cascadePath)

font = cv2.FONT_HERSHEY_SIMPLEX

# Names related to ids: example ==> 0: 'Hittanshu', 1: 'Vedant', etc
names = ['None', 'Hittanshu', 'Vedant']

# Initialize and start real-time video capture
cam = cv2.VideoCapture(0)
cam.set(3, 640)  # set video width
cam.set(4, 480)  # set video height

# Define min window size to be recognized as a face
minW = 0.1 * cam.get(3)
minH = 0.1 * cam.get(4)

while True:
    ret, img = cam.read()

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.2,
        minNeighbors=5,
        minSize=(int(minW), int(minH))
    )

    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)

        # Predict the id and confidence of the face
        id, confidence = recognizer.predict(gray[y:y+h, x:x+w])

        # Ensure that the predicted id is within the valid range
        if 0 <= id < len(names):
            name = names[id]
            confidence = "  {0}%".format(round(100 - confidence))
        else:
            name = "unknown"
            confidence = "  {0}%".format(round(100 - confidence))

        cv2.putText(img, str(name), (x+5, y-5), font, 1, (255, 255, 255), 2)
        cv2.putText(img, str(confidence), (x+5, y+h-5), font, 1, (255, 255, 0), 1)

    cv2.imshow('camera', img)

    k = cv2.waitKey(10) & 0xff  # Press 'ESC' for exiting video
    if k == 27:
        break

# Do a bit of cleanup
print("\n [INFO] Exiting Program and cleanup stuff")
cam.release()
cv2.destroyAllWindows()
